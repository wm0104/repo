# Corresponding source: wiki.qaq.apelin.agent-tools.assembler 1.0.0

The `apelin-assembler` executable in this package contains Keystone, which
is licensed under the GNU General Public License version 2 only (`COPYING`
beside this file; LLVM-derived parts also under `LLVM-LICENSE.TXT`). You may
copy, modify and redistribute it under that license. Apelin's own code in it
is MIT (`../Apelin/LICENSE`).

The complete corresponding source of this executable, with the scripts used
to build and package it, is:

- `wiki.qaq.apelin.agent-tools.assembler_1.0.0_source.tar.xz` (SHA-256 `6a1b13f482cede1bc6bfb8a1806acc81c49b2cca9cfacb73eaf9faffff723fe6`), published beside this
  package wherever this package is published;
- and, equivalently, these public repositories at these revisions:
  - Apelin, https://github.com/owngoal-dev/Apelin at commit `994b7d7f3e9d97b84942eb9fd555f771286ca3cb`:
    `Packages/ApelinToolHost` and `Extensions/AgentTools/Disassembler`;
  - libkeystone-spm (Keystone as a Swift package),
    https://github.com/Lakr233/libkeystone-spm at commit `3ff184008e1ba49577b944579cd32d32c78451b5`.

To rebuild: install Xcode and run
`Extensions/AgentTools/Disassembler/Scripts/build-agent-tools.sh` in an
Apelin checkout. The archive holds that tree under `Apelin/`, and the two
Swift packages it depends on under `Dependencies/` (libkeystone-spm, and
libcapstone-spm, which the same package graph names); to build from the
archive without the network, first run, in
`Apelin/Extensions/AgentTools/Disassembler`,
`swift package edit libkeystone-spm --path ../../../../Dependencies/libkeystone-spm`
and the same for libcapstone-spm.
