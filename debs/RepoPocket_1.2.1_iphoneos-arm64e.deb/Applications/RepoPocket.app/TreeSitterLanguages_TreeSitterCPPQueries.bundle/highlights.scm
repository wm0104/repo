; inherits: c

; Functions

(call_expression
  function: (qualified_identifier
    name: (identifier) @function.call))

(template_function
  name: (identifier) @function.call)

(template_method
  name: (field_identifier) @function.call)

(template_function
  name: (identifier) @function.call)

(function_declarator
  declarator: (qualified_identifier
    name: (identifier) @function.definition))

(function_declarator
  declarator: (field_identifier) @function.definition)

; Types

((namespace_identifier) @type
 (#match? @type "^[A-Z]"))

(auto) @type

; Constants

(this) @variable.builtin
(null "nullptr" @constant)

; Modules
(module_name
  (identifier) @namespace)

; Keywords

[
 "catch"
 "class"
 "co_await"
 "co_return"
 "co_yield"
 "constexpr"
 "constinit"
 "consteval"
 "delete"
 "explicit"
 "final"
 "friend"
 "mutable"
 "namespace"
 "noexcept"
 "new"
 "override"
 "private"
 "protected"
 "public"
 "template"
 "throw"
 "try"
 "typename"
 "using"
 "concept"
 "requires"
 "virtual"
 "import"
 "export"
 "module"
] @keyword

; Strings

(raw_string_literal) @string
